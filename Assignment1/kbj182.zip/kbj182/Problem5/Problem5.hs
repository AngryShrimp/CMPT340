--Keenan Johnstone
--Cmpt340 Assignment 1
--Jan 31, 2016

compose3 :: (a -> b) -> (c -> b) -> (d -> c) -> (d -> a)